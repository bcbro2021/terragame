import pygame
from .assetReader import *
from pygame import *

class Player():
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.tex = assetLoader("src/assets/player.assets")
        self.w = self.tex[0].get_width()
        self.h = self.tex[0].get_height()
        self.speed = 3
        self.moveLeft = False
        self.speedLimit = 6
        self.air_timer = 0
        self.moveRight = False
        self.c = (255,255,255)
        self.gravity = 0
        self.gravity_speed = 0.2
        self.rect = pygame.Rect(self.x,self.y,self.w,self.h)
    def events(self,event):
        if event.type == KEYDOWN:
            if event.key == K_a:
                self.moveLeft = True
            if event.key == K_d:
                self.moveRight = True
            if event.key == K_SPACE:
                if self.air_timer < 6:
                    self.gravity = -5
                    self.jumping = True
        if event.type == KEYUP:
            if event.key == K_a:
                self.moveLeft = False
            if event.key == K_d:
                self.moveRight = False
    
    def update(self,win,tile_rects):
        #movement
        player_movement = [0,0]
        if self.moveLeft == True:
            player_movement[0] -= self.speed
        if self.moveRight == True:
            player_movement[0] += self.speed

        #gravity
        self.gravity += self.gravity_speed
        player_movement[1] += self.gravity
        if self.gravity > 4:
            self.gravity = 4

        #movement continued
        self.rect, collisions = self.move(player_movement,tile_rects)
        if collisions["bottom"]:
            self.gravity = 0
            self.air_timer = 0
        else:
            self.air_timer += 1
    
        win.blit(self.tex[0],(self.rect.x,self.rect.y))
    def collision_test(self,tiles):
        hit_list = []
        for tile in tiles:
            if self.rect.colliderect(tile):
                hit_list.append(tile)
        return hit_list
    def move(self,movement,tiles):
        collision_types = {"top":False,"bottom":False,"left":False,"right":False}
        self.rect.x += movement[0]
        hit_list = self.collision_test(tiles)
        for tile in hit_list:
            if movement[0] > 0:
                self.rect.right = tile.left
                collision_types["right"] = True
            elif movement[0] < 0:
                self.rect.left = tile.right
                collision_types["left"] = True
        self.rect.y += movement[1]
        hit_list = self.collision_test(tiles)
        for tile in hit_list:
            if movement[1] > 0:
                self.rect.bottom = tile.top
                collision_types["bottom"] = True
            elif movement[1] < 0:
                self.rect.top = tile.bottom
                collision_types["top"] = True
        return self.rect, collision_types
