import pygame
def assetLoader(assetsFile):
    file = open(assetsFile, "r")
    assets = []
    for line in file.readlines():
        asset = pygame.image.load(line)
        assets.append(asset)
    return assets